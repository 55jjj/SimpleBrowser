# 简单浏览器

一个轻量级 Android 浏览器应用，使用 WebView 实现真实网页浏览。

## 功能

- 访问任意网址（Google、Baidu、知乎等均可正常加载）
- 前进 / 后退 / 刷新
- 地址栏输入 + 搜索
- 加载进度条
- 暗色模式适配
- 物理返回键优先网页后退

## 云端编译步骤（无需电脑）

### 1. 创建 GitHub 仓库

- 打开 [github.com](https://github.com)
- 登录账号 → 点击右上角 **+** → **New repository**
- 仓库名填 `SimpleBrowser`
- 选择 **Public**
- 点击 **Create repository**

### 2. 上传代码

在仓库页面：

1. 点击 **uploading an existing file** 链接
2. 把本 ZIP 解压后的所有文件和文件夹拖入上传区域
3. 确保包含 `.github/workflows/build.yml`
4. 点击 **Commit changes**

### 3. 等待自动编译

- 点击仓库顶部的 **Actions** 标签
- 你会看到 **Build APK** 工作流正在运行
- 等待约 3-5 分钟，直到状态变成 ✅ 绿色

### 4. 下载 APK

- 点击完成的 workflow 记录
- 页面底部找到 **Artifacts** 区域
- 点击 **app-debug** 下载 ZIP
- 解压后得到 `app-debug.apk`，传到手机安装即可

## 手机安装

1. 把 `app-debug.apk` 传到手机（微信、QQ、邮件均可）
2. 手机上点击 APK 文件
3. 如果提示"未知来源"，去设置里允许当前应用安装
4. 安装完成，桌面出现"简单浏览器"图标

## 系统要求

- Android 7.0 及以上（API 24+）
- 需要联网
